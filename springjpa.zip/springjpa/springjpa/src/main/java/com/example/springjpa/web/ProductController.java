package com.example.springjpa.web;

import com.example.springjpa.entity.Product;
import com.example.springjpa.persistence.ProductRepository;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
public class ProductController {
    private ProductRepository repository;
    @PostMapping(path = "products")
    public Product save(String name,String description, Double price){
        Product product = new Product(name,description,price,null);
        product = repository.save(product);
        return product;
    }
    @GetMapping(path = "products")
    public List<Product>  findAll(){
        return repository.findAll();
    }
    @GetMapping(path = "products/{name}")
    public Product findByName(@PathVariable(name = "name")String name){
        Product product = null;

        Optional<Product> optional = repository.findByName(name);
        if(optional.isPresent()){
            product = optional.get();
        }

        return product;
    }


    @DeleteMapping(path = "´products/{id}")
    public Product remove(@PathVariable(name = "id")Integer id){
        Product product = null;
        Optional<Product> optional = repository.findById(id);
        if (optional.isPresent()){
            product = optional.get();
            repository.delete(product);
        }
        return product;
    }
}
